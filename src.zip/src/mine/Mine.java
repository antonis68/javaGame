package mine;

import java.awt.Color;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Timer;
import java.util.TimerTask;


import javax.swing.JButton;
import javax.swing.JFrame;

import javax.sound.sampled.*;
import javax.swing.JLabel;


import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;


/**
 * @author spanomarias68
 * email: spanomarias68@gmail.com
 */
public class Mine extends TimerTask implements ActionListener
{

    private JFrame frame;
    private JButton mineBtn;
    private Font font;
    private int totalMine = 80;
    private int kato = 0;
    private int deksia = 0;
    private int totalBombe = 10;
    private Clip test;
    private JLabel timeLabel;
    private JLabel bombLabel;
    private Timer timer;
    private int timerCount = 0;
    private int noBomb = 0;
    private boolean run = false;
    private boolean gameOver = false;
    private boolean rounded=false;
    private JMenu menuLevel;
    private ArrayList<Integer> mineList = new ArrayList<Integer>();
    private ArrayList<Integer> bombeList = new ArrayList<Integer>();
    private ArrayList<Integer> zeroAroundList=new ArrayList<>();
    private JMenuBar menuBar;
    private JMenuItem lvl1;
    private JMenuItem lvl2;
    private JMenuItem lvl3;

    /**
     * Launch the application.
     */
    public static void main(String[] args)
    {
	EventQueue.invokeLater(new Runnable()
	{
	    public void run()
	    {
		try
		{
		    Mine window = new Mine();
		    window.frame.setVisible(true);

		} catch (Exception e)
		{
		    e.printStackTrace();
		}
	    }
	});
    }

    /**
     * Create the application.
     * 
     * @throws IOException
     * @throws UnsupportedAudioFileException
     * @throws LineUnavailableException
     */
    public Mine() throws UnsupportedAudioFileException, IOException, LineUnavailableException
    {

	initialize();
	frame.getContentPane().setLayout(null);

	menuBar = new JMenuBar();
	menuBar.setBounds(0, 0, 97, 21);
	frame.getContentPane().add(menuBar);

	menuLevel = new JMenu("Select Level");
	menuLevel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
	menuBar.add(menuLevel);

	lvl1 = new JMenuItem("Level 1 (10 Mines)");
	lvl1.addActionListener(new ActionListener()
	{
	    public void actionPerformed(ActionEvent e)
	    {
		totalBombe = 10;
		resetGame();

	    }
	});
	menuLevel.add(lvl1);

	lvl2 = new JMenuItem("Level 2 (15 Mines)");
	lvl2.addActionListener(new ActionListener()
	{
	    public void actionPerformed(ActionEvent e)
	    {
		totalBombe = 15;
		resetGame();
	    }
	});
	menuLevel.add(lvl2);

	lvl3 = new JMenuItem("Level 3 (25 Mines)");
	lvl3.addActionListener(new ActionListener()
	{
	    public void actionPerformed(ActionEvent e)
	    {
		totalBombe = 25;
		resetGame();
	    }
	});
	menuLevel.add(lvl3);
	font = new Font(null, 0, 25);
	timer = new Timer(true);
	timer.schedule(this, 1000, 1000);
	lvl1.setEnabled(totalBombe != 10);
	setBombe();
	setMine();

    }

    private void setMine()
    {

	for (int i = 0; i < totalMine; i++)
	{
	    mineBtn = new JButton();
	    mineBtn.setName("btnMine_" + String.valueOf(i));
	    mineBtn.addActionListener((ActionListener) this);
	    mineBtn.setBounds(50 * deksia + 5, kato + 25, 50, 50);
	    mineBtn.setBackground(new Color(0xbfcddb));
	    mineBtn.setText("");
	    mineBtn.setFont(font);
	    mineList.add(bombeList.get(i));

	    deksia++;
	    if ((50 * deksia) % 500 == 0 && i > 0)
	    {
		deksia = 0;
		kato += 50;
	    }
	    frame.getContentPane().add(mineBtn);
	    int index = frame.getContentPane().getComponentZOrder(mineBtn);
	    mineBtn.setActionCommand(String.valueOf(index));

	}
	bombLabel.setText("Total Mines: 10");
    }

    public void actionPerformed(ActionEvent event)
    {
	if (gameOver)
	{
	    return;
	}
	run = true;
	int btnIndex = Integer.valueOf(event.getActionCommand());
	JButton btn = (JButton) frame.getContentPane().getComponent(btnIndex);
	
	if (isBomb(btnIndex - 4))
	{
	    try
	    {
		btn.setBackground(new Color(0xff2200));
		btn.setText("*");
		gameover(false);
		playSound(false);
		showAll(false);
	    } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e)
	    {
		e.printStackTrace();
	    }
	} else
	{
	    btn.setBackground(new Color(0x00ff00));
	    btn.setText(String.valueOf(checkBomb(btnIndex - 4,"")));
	    if(checkBomb(btnIndex - 4,"")==0 && !rounded)
	    {
		checkBomb(btnIndex - 4,"zeroArround");
		showAroundZero();
	    }
	    noBomb++;
	    if (noBomb == (totalMine - totalBombe))
	    {
		gameover(true);
		try
		{
		    showAll(true);
		    playSound(true);
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e)
		{
		   
		    e.printStackTrace();
		}
	    }

	}

	btn.setEnabled(false);

	
    }
    private void showAroundZero()
    {
     rounded=true;	
     int total=zeroAroundList.size();
     for(int i=0;i<total;i++)
     {
      int index=zeroAroundList.get(i);
      JButton btn=(JButton) frame.getContentPane().getComponent(index);
      btn.doClick();
      
     }
    
     zeroAroundList=new ArrayList<>();
     rounded=false;
     
    }
    private void showAll(boolean success)
    {
	int total = frame.getContentPane().getComponentCount();
	for (int i = 0; i < total; i++)
	{
	    try
	    {
		JButton comp = (JButton) frame.getContentPane().getComponent(i);
		if (comp.getName() != null)
		{
		    int index = frame.getContentPane().getComponentZOrder(comp);
		    if(isBomb(index-4))
		    {
			if(!success){comp.setBackground(new Color(0xff2200));}
			comp.setText("*");
		    }
		    else
		    {
		     comp.setBackground(new Color(0x00ff00));
		     comp.setText(String.valueOf(checkBomb(index - 4,"")));
		    
		    }
		  }
	    } catch (Exception e)
	    {
		
	    }
	}
    }

    private int checkBomb(int index,String cmd)
    {
	int around = 0;
	int arIndex = 0;
	int modul = 0;
	int bombe = 0;
	
	for (int i = 0; i < 8; i++)
	{
	    bombe = 0;
	    switch (i)
	    {
	    case 0:
		arIndex = -1;
		break;
	    // --------
	    case 1:
		arIndex = -11;
		break;
	    // ---------
	    case 2:
		arIndex = -10;
		break;

	    case 3:
		arIndex = -9;
		break;
	    case 4:
		arIndex = 1;
		break;
	    case 5:
		arIndex = 11;
		break;
	    case 6:
		arIndex = 10;
		break;
	    case 7:
		arIndex = 9;
		break;
	    }
	    modul = (index) % 10;

	    try
	    {
		

		if (allow(modul, arIndex))
		{
		   bombe = bombeList.get(index + arIndex);
		   if(cmd=="")
		   {
		   if (bombe == 1)
		    {
			around++;
		    }
		   }
		   else
		   {
		     zeroAroundList.add(index+arIndex+4);
		           
		   }
		}

	    } catch (Exception e)
	    {

	    }
	}
	if(cmd==""){return around;}
	else{return 0;}
    }

    private boolean allow(int modul, int arIndex)
    {
	if (modul == 0 && (arIndex == -1 || arIndex == -11 || arIndex == 9))
	{
	    return false;
	}
	if (modul == 9 && (arIndex == 1 || arIndex == 11 || arIndex == -9))
	{
	    return false;
	}
	return true;
    }

    private boolean isBomb(int index)
    {
	if (bombeList.get(index) == 1)
	{
	    return true;
	}
	return false;
    }

    private void setBombe()
    {
	bombeList = new ArrayList<>();
	for (int i = 0; i < totalMine; i++)
	{
	    if (i < totalBombe)
	    {
		bombeList.add(1);
	    } else
	    {
		bombeList.add(0);
	    }

	}
	Collections.shuffle(bombeList);

    }

    private void gameover(boolean success)
    {

	gameOver = true;
	if (!success)
	{
	    timeLabel.setText("Game Over");
	    timeLabel.setForeground(Color.RED);
	} else
	{
	    timeLabel.setText("Success. Time: " + timerCount);
	    timeLabel.setForeground(Color.GREEN);
	}
    }

    private void playSound(boolean bool) throws UnsupportedAudioFileException, IOException, LineUnavailableException
    {
	String path = System.getProperty("user.dir");
	String wavPath; 
	
	if (bool)
	{
	    wavPath = "/sound/success.wav";
	} else
	{
	    wavPath = "/sound/bomb.wav";
	}
	try
	{
	 AudioInputStream stream = AudioSystem.getAudioInputStream(new File(path + wavPath));
	 test = AudioSystem.getClip();
	 test.open(stream);
	 test.start();
	}catch (Exception e) {
	     
	}
	}

    // ---------------------
    private void initialize()
    {
	frame = new JFrame();
	frame.setResizable(false);
	frame.getContentPane().setBackground(Color.DARK_GRAY);
	frame.setBounds(100, 100, 525, 500);
	frame.setTitle("Mine");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	timeLabel = new JLabel("Time:");
	timeLabel.setForeground(Color.WHITE);
	timeLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
	timeLabel.setBounds(212, 436, 188, 14);
	frame.getContentPane().add(timeLabel);

	bombLabel = new JLabel("Total Mines:" + totalBombe);
	bombLabel.setForeground(Color.WHITE);
	bombLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
	bombLabel.setBounds(10, 436, 132, 14);
	frame.getContentPane().add(bombLabel);

	JButton new_btn = new JButton("New");
	new_btn.addActionListener(new ActionListener()
	{
	    public void actionPerformed(ActionEvent arg0)
	    {
		resetGame();
	    }
	});
	new_btn.setBounds(410, 433, 89, 23);
	frame.getContentPane().add(new_btn);
    }

    private void resetGame()
    {

	timerCount = 0;
	noBomb = 0;
	run = false;
	gameOver = false;
	kato = 0;
	deksia = 0;
	zeroAroundList=new ArrayList<>();
	rounded=false;
	int count = frame.getContentPane().getComponentCount();
	for (int i = 0; i < count; i++)
	{
	    try
	    {
		JButton comp = (JButton) frame.getContentPane().getComponent(i);
		if (comp.getName() != null)
		{
		    comp.setBackground(new Color(0xbfcddb));
		    comp.setEnabled(true);
		    comp.setText("");
		}
	    } catch (Exception e)
	    {
		
	    }

	}
	lvl1.setEnabled(totalBombe != 10);
	lvl2.setEnabled(totalBombe != 15);
	lvl3.setEnabled(totalBombe != 25);
	frame.getContentPane().repaint();
	bombLabel.setText("Total Mines: " + totalBombe);
	timeLabel.setForeground(Color.WHITE);
	timeLabel.setText("Timer:");
	setBombe();

    }

    @Override
    public void run()
    {
	
	if (run && !gameOver)
	{
	    timerCount++;
	} else
	{
	    return;
	}
	timeLabel.setText("Time: " + timerCount);

	

    }
}
